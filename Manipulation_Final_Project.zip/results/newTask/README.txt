Type of controller: feedforwad plus PI
feedback gains: Kp = (identity)*2, Ki = (identity)*2
    -adjust this in lines 230-232 of main.py
CSV filename: configs_newTask.csv
initial rotation of cube config: 90 about x
initial translation of cube config: 1.2 about x and 0.025 about z
desired rotation of cube config: 90 about x and 90 about z
desired translation of cube config: -1.2 about y and 0.025 about z
    -uncomment lines 22 and 25 and comment out lines 21 and 24 from main.py to run with the custom configs
